    
    winningpattern=[[0,1,2],
[0,3,6],[0,4,8],[1,4,7],[2,5,8],[2,4,6],[3,4,5],[6,7,8]

]
msg=document.getElementById("msg");
msg.classList.add("hide");
mywinner=document.getElementById("winner");

turn=document.getElementById("myturn");
boxes=document.querySelectorAll(".boxs");
turnx=true;
boxes.forEach(element => {
    element.addEventListener("click",function(){
        if(turnx){
            element.innerText="x";
            turnx=false;
            element.disabled=true;
            element.style.backgroundColor='yellow'
            turn.innerText="Turn O"

        }
        else{
            element.innerText="O";
            turnx=true;
            element.disabled=true;
            turn.innerText="Turn X"

        }

        checkwinner();
    })
    
});

function checkwinner(){
    for (const pattern of winningpattern) {
       

       let ps0=boxes[pattern[0]].innerText;
       let ps1=boxes[pattern[1]].innerText;
       let ps2=boxes[pattern[2]].innerText;
      
if(ps0!="" && ps1!="" && ps2!=""){
    if(ps0==ps1 && ps1==ps2){
        console.log("winner",ps1)
        boxdisabled();
        msg.classList.remove("hide");
        window.scrollTo(0,0);

        mywinner.innerText="Winner is"+" "+ps1;

    }
    
    
}



        
    }
    

}

function boxdisabled(){
    boxes.forEach(element =>{
        element.disabled=true;
    })
}

function newgame(){
    turnx=true;
    boxes.forEach(element =>{
        element.disabled=false;
        element.innerText="";
        element.style.backgroundColor='#EFEFEF'
    })
    window.scrollTo(0,1000)
    turn.innerText="";

}
function reset(){
    turnx=true;
    boxes.forEach(element =>{
        element.disabled=false;
        element.innerText="";
        element.style.backgroundColor='#EFEFEF'
    })
    turn.innerText=""


}